import logo from "./logo.svg";
import "./App.css";
import Checkout from "./components/checkout/Checkout";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Checkout />
      </header>
    </div>
  );
}

export default App;
